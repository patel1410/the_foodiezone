"""TheFoodieZone URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from seller import views

urlpatterns = [
    path('dashboard', views.dashboard, name='dashboard'),
    path('header', views.header, name='header'),
    path('layout', views.layout, name='layout'),
    
    path('add_category', views.add_category, name='add_category'),
    path('store_category', views.store_category, name='store_category'),
    path('all_category', views.all_category, name='all_category'),
    path('delete_category/<int:id>', views.delete_category, name='delete_category'),
    path('add_category_edit/<int:id>', views.add_category_edit, name='add_category_edit'),
    path('add_category_update/<int:id>', views.add_category_update, name='add_category_update'),

    path('add_fooditems', views.add_fooditems, name='add_fooditems'),
    path('store_fooditem/<int:id>', views.store_fooditem, name='store_item'),
    path('all_fooditem', views.all_fooditem, name='all_fooditem'),
    # path('edit_fooditem/<int:id>', views.edit_fooditem, name='edit_fooditem'),
    path('delete_fooditem/<int:id>', views.delete_fooditem, name='delete_fooditem'),
    # path('edit/<int:id>', views.edit, name='edit'),
    path('all_item_edit/<int:id>', views.all_item_edit, name='all_item_edit'),
    path('all_item_update/<int:id>', views.all_item_update, name='all_item_update'),
    
    path('seller_login', views.seller_login, name='seller_login'),
    path('login_check', views.login_check, name='login_check'),
    path('logout', views.logout, name='logout'),

    path('seller_registerform', views.seller_registerform, name='seller_registerform'),

    path('view_feedback', views.view_feedback, name='view_feedback'),
    path('store_seller', views.store_seller, name='store_seller'),
    
    path('order_read',views.order_read,name='order_read'),
    path('order_details/<int:id>',views.order_details,name='order_details')

]
