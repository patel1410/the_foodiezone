from django.shortcuts import render, redirect
from seller.models import *
from django.core.files.storage import FileSystemStorage
from django.contrib import auth, messages
from django.conf import settings
import os

# Create your views here.


def dashboard(request):
    context = {}
    return render(request, 'seller/dashboard.html', context)


def header(request):
    id = request.user.id
    seller = Seller.objects.get(user_id=id)
    sellers=Seller.objects.filter(seller_id=seller.id)
    context={'sellers':sellers}
    return render(request, 'seller/common/header.html', context)



def layout(request):
    context = {}
    return render(request, 'seller/common/layout.html', context)


def add_category(request):
    context = {}
    return render(request, 'seller/add_category.html', context)


def store_category(request):
    category_name = request.POST['category_name']
    id = request.user.id
    seller = Seller.objects.get(user_id=id)
    seller_id = seller.id

    Sub_category.objects.create(
        category_name=category_name, seller_id=seller_id)
    return redirect("/seller/add_category")


def all_category(request):
    id = request.user.id
    seller = Seller.objects.get(user_id=id)
    category = Sub_category.objects.filter(seller_id=seller.id)
    context = {'category': category}
    return render(request, 'seller/all_category.html', context)


def delete_category(request, id):
    result = Sub_category.objects.get(pk=id)
    result.delete()
    return redirect("/seller/all_category")


def add_category_edit(request,id):
	category = Sub_category.objects.get(pk=id)
	context = {'category':category}
	return render(request,"seller/edit_category.html",context)

def add_category_update(request,id):
	data = {
			 'category_name' : request.POST['category_name'],	
		   }
	Sub_category.objects.update_or_create(pk=id,defaults=data)
	return redirect('/seller/all_category')


def add_fooditems(request):
    id = request.user.id
    seller = Seller.objects.get(user_id=id)
    result = Seller.objects.all()
    result1 = Sub_category.objects.filter(seller_id=seller.id)
    context = {'sellers': result, 'category': result1}
    return render(request, 'seller/add_fooditems.html', context)


def store_fooditem(request, id):
    name = request.POST['name']
    price = request.POST['price']
    myfile = request.FILES['image']
    id = request.user.id
    seller = Seller.objects.get(user_id=id)
    seller_id = seller.id
    mylocation = os.path.join(settings.MEDIA_ROOT, 'upload')
    obj = FileSystemStorage(location=mylocation)
    obj.save(myfile.name, myfile)

    mysubcategory = request.POST['sub_category']

    mycategory = request.POST['Category']
    quantity = request.POST['quantity']
    description = request.POST['description']

    Add_fooditem.objects.create(name=name, price=price, image=myfile.name, Category=mycategory,
                                sub_category_id=mysubcategory, seller_id=seller_id, quantity=quantity, description=description)
    return redirect('/seller/add_fooditems')


def all_fooditem(request):
    id = request.user.id
    seller = Seller.objects.get(user_id=id)
    category = Add_fooditem.objects.filter(seller_id=seller.id)
    context = {'category': category}
    return render(request, 'seller/all_fooditem.html', context)


def delete_fooditem(request, id):
    result = Add_fooditem.objects.get(pk=id)
    result.delete()
    return redirect("/seller/all_fooditem")


def all_item_edit(request,id):
    id = request.user.id
    seller = Seller.objects.get(user_id=id)
    result=Add_fooditem.objects.get(pk=id)
    result1 = Seller.objects.all()
    result2 = Sub_category.objects.filter(seller_id=seller.id)
    data = {'result':result,'sellers':result1,'category':result2}
    return render(request,'seller/edit_fooditem.html',data)

def all_item_update(request,id):
	myname        = request.POST['name']
	myprice       = request.POST['price']
	myquantity    = request.POST['quantity']
	mycategory    = request.POST['category']
	mydescription = request.POST['description']

	if len(request.FILES)!=0:
		myfile     = request.FILES['image']
		mylocation = os.path.join(settings.MEDIA_ROOT, 'upload')
		obj        = FileSystemStorage(location=mylocation)
		obj.save(myfile.name, myfile)
		filename = myfile.name
	else:
		result = Add_fooditem.objects.get(pk=id)
		filename = result.image

	data = {
		'name' : request.POST['name'],
		'price' : request.POST['price'],
		'quantity':request.POST['quantity'],
	    'image' : filename,
	    'category_id' : request.POST['category'],
	    'description' : request.POST['description']
	}
	Add_fooditem.objects.update_or_create(pk=id, defaults=data)
	return redirect('/seller/all_fooditem')


def view_feedback(request):
    result = Feedback.objects.all()
    context = {'result': result}
    return render(request, 'seller/view_feedback.html', context)


def seller_login(request):
    context = {}
    return render(request, 'seller/seller_login.html', context)


def seller_registerform(request):
    result = City.objects.all()
    result1 = Area.objects.all()
    context = {'city': result, 'area': result1}
    return render(request, 'seller/seller_registrationform.html', context)


def store_seller(request):
    # User Model
    name = request.POST['name']
    email = request.POST['email']
    username = request.POST['username']
    password = request.POST['password']
    cpassword = request.POST['cpassword']

    myfile = request.FILES['image']

    mylocation = os.path.join(settings.MEDIA_ROOT, 'upload')
    obj = FileSystemStorage(location=mylocation)
    obj.save(myfile.name, myfile)

    contact = request.POST['contact']
    address = request.POST['address']
    mycity = request.POST['city']
    myarea = request.POST['area']
    if password == cpassword:
        result = User.objects.create_user(
            first_name=name, email=email, username=username, password=password)
        Seller.objects.create(contact=contact, address=address, image=myfile.name,
                              city_id=mycity, area_id=myarea, user_id=result.id)
        messages.success(request, 'Registered Sucessfully',
                         extra_tags='signup')
        return redirect('/seller/seller_login')
    else:
        # print('Missmatch Password')
        messages.error(request, "password is not matched")
        return redirect('/seller/seller_registerform')


def login_check(request):
    username = request.POST.get('username')
    password = request.POST.get('password')
    result = auth.authenticate(request, username=username, password=password)
    print(result)
    if result is None:
        messages.error(
            request, "username or password is incorrect. Try again.")
        return redirect('/seller/seller_login')
    else:
        auth.login(request, result)
        return redirect('/seller/dashboard')


def logout(request):
    auth.logout(request)
    return redirect('/customer/home')


def order_read(request):
     id = request.user.id
     seller = Seller.objects.get(user_id=id)
     order=Order.objects.filter(seller_id=seller.id)
     context={'order':order}
     return render(request, 'seller/all_order.html', context)


def order_details(request,id):
    order=Order.objects.get(pk=id)
    result=Order_details.objects.filter(order_id=order.id)
    context={'result':result}
    
    return render(request, 'seller/all_order_details.html', context)

     


