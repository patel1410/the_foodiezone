from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib import auth, messages
from seller.models import *
from django.core.paginator import Paginator
import razorpay
from io import BytesIO
from django.core.mail import EmailMessage
from reportlab.pdfgen import canvas 
from reportlab.lib.pagesizes import letter, portrait
from reportlab.lib import colors
from reportlab.lib.units import inch
from datetime import datetime

from django.http import FileResponse
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Count

# Create your views here.

def home(request):


    if request.user.is_authenticated:
        customer = Customer.objects.get(user_id=request.user.id)
        total = Cart.objects.aggregate(total_items=Count(customer.id))
        seller = Seller.objects.all()
        paginator = Paginator(seller, 6)
        page = request.GET.get('page')
        seller_page = paginator.get_page(page)
        context = {'seller_page':seller_page, 'total_items':total['total_items']}
        return render(request,'customer/home.html',context)
    else :
        seller = Seller.objects.all()
        paginator = Paginator(seller, 6)
        page = request.GET.get('page')
        seller_page = paginator.get_page(page)
        context = {'seller_page':seller_page}
        return render(request,'customer/home.html',context)

def layout(request):
    
    if request.user.is_authenticated:
        customer = Customer.objects.get(user_id=request.user.id)
        total = Cart.objects.aggregate(total_items=Count(customer.id))
        context = { 'total_items':total['total_items']}
        return render(request,'customer/common/layout.html',context)
    else:
        context={}
        return render(request,'customer/common/layout.html',context)


def header(request):
    context = {}
    return render(request,'customer/common/header.html',context)

def sidebar(request):
    context = {}
    return render(request,'customer/common/sidebar.html',context)

def footer(request):
    context = {}
    return render(request,'customer/common/footer.html',context)


# def registration(request):
# 	return render(request,'customer/registration.html')

def login(request):
	return render(request,'customer/login.html')

def registration(request):
	result = City.objects.all()
	result1 = Area.objects.all()
	context = {'city':result,'area':result1}
	return render(request,'customer/registration.html',context)

def store_customer(request):
    # User Model
    name     = request.POST['name']
    email     = request.POST['email']
    username  = request.POST['username']
    password  = request.POST['password']
    cpassword = request.POST['cpassword']                               

    contact = request.POST['contact']
    address = request.POST['address']
    gender=request.POST['gender']
    dob= request.POST['birth_date']
    mycity=request.POST['city']
    myarea=request.POST['area']

    if password == cpassword:
        result = User.objects.create_user(first_name=name,email=email,username=username,password=password)
        Customer.objects.create(contact=contact,dob=dob,address=address,gender=gender,city_id=mycity,area_id=myarea,user_id=result.id)
        messages.success(request, 'Registered Sucessfully', extra_tags='signup')
        return redirect('/customer/login')
    else:
        # print('Missmatch Password')
        messages.error(request,"password is not matched")
        return redirect('/customer/registration')


def login_check(request):
    username = request.POST.get('username')
    password = request.POST.get('password')

    result = auth.authenticate(request, username=username, password=password)
    print(result)
    if result is None:
        messages.error(request,'Invalid Username Or Password')
        return redirect('/customer/login')
    else:
        auth.login(request,result)
        return redirect('/customer/home')
    

def logout(request):
    auth.logout(request)
    return redirect('/customer/home')
     
    
def inquiry(request):
     context={}
     return render(request,'customer/inquiry.html',context)

def store_inquiry(request,id):
    name=request.POST['name']
    email=request.POST['email']
    contact=request.POST['contact']
    message=request.POST['message']
    id = request.user.id
    customer = Customer.objects.get(user_id=id)
    customer_id = customer.id

    Inquiry.objects.create(name=name,email=email,contact=contact,message=message,customer_id=customer_id)
    return redirect('/customer/home')

def feedback(request):
     context={}
     return render(request,'customer/feedback.html',context)


def store_feedback(request,id):
    feedback=request.POST['feedback']
    myrating=request.POST['rating']
    id = request.user.id
    customer = Customer.objects.get(user_id=id)
    customer_id = customer.id

    Feedback.objects.create(feedback=feedback,rating=myrating,customer_id=customer_id)
    return redirect('/customer/home')


def res_load(request):
    seller = Seller.objects.all()
    paginator = Paginator(seller, 6)
    page = request.GET.get('page')
    seller_page = paginator.get_page(page)
    context = {'seller_page':seller_page}
    return render(request,'customer/res_load.html',context)

def resturant_category(request,id):
    category = Sub_category.objects.filter(seller_id=id)
    allitem = Add_fooditem.objects.filter(seller_id=id)
    items = Add_fooditem.objects.all()

    
    context = {'items':items,'category':category,'allitem':allitem,'res_id':id}
 
    return render(request,'customer/resturant_category.html',context)


def fooditems(request,id,res_id):
    print('cat_id =',id)
    print('res id =',res_id)
    category = Sub_category.objects.filter(seller_id=res_id)
    item =Add_fooditem.objects.filter(sub_category_id=id)
    context = {'item':item,'category':category,'res_id':res_id}
    return render(request,'customer/fooditems.html',context)



def view_cart(request):
    id1 = request.user.id
    c1 = Customer.objects.get(user_id=id1)
    cart = Cart.objects.filter(customer_id=c1.id)
    total=0
    for row in cart:
        p = int(row.food_item.price)
        total = (p * int(row.quantity)) +total
    
    context = {'cart':cart,'total':total}
    return render(request,'customer/view_cart.html',context)

def add_cart(request, id):
    customer = Customer.objects.get(user_id=request.user.id)
    cart_data = Cart.objects.filter(food_item_id=id, customer_id=customer.id)

    if cart_data.exists():
        data = {
                 'quantity': int(cart_data[0].quantity) + 1 
              }
        Cart.objects.update_or_create(pk=cart_data[0].id, defaults=data)
        return redirect('/customer/view_cart')
    else:
        p_price = Add_fooditem.objects.get(pk=id)
        Cart.objects.create(food_item_id=id,customer_id=customer.id,quantity=1,price=p_price.price,seller_id=p_price.seller.id)

   
    return redirect(request.META.get('HTTP_REFERER'))

def remove_item(request,id):
    result = Cart.objects.get(pk=id)
    result.delete()
    return redirect(request.META.get('HTTP_REFERER'))

def update_cart(request):
    cart_id = request.GET['cart_id']
    quantity = request.GET['quantity']

    data = {
             'quantity': quantity 
          }
    Cart.objects.update_or_create(pk=cart_id, defaults=data)
    return redirect('/customer/view_cart')


def checkout(request):
    id1 = request.user.id
    c1 = Customer.objects.get(user_id=id1)
    cart = Cart.objects.filter(customer_id=c1.id)
    city=City.objects.all()
    area=Area.objects.all()
    sub_total = 0
    shipping=0
    for row in cart:
        p = int(row.food_item.price)
        sub_total = (p * int(row.quantity)) + sub_total
        total =sub_total+shipping
    context={'city':city,'area':area,'cart':cart,'c1':c1,'sub_total':sub_total,'total':total}
    return render(request,'customer/checkout_details.html',context)


def place_order(request):
    cus = Customer.objects.get(user_id=request.user.id)
    cart = Cart.objects.filter(customer_id=cus.id)
    method = request.POST['method']
    ship_bill = request.POST['ship_bill']

    if ship_bill == 'yes':
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        address = request.POST['address']
        city = request.POST['city']
        area = request.POST['area']
        pin = request.POST['pin']

        sname = request.POST['sname']
        semail = request.POST['semail']
        sphone = request.POST['sphone']
        saddress = request.POST['saddress']
        scity = request.POST['scity']
        sarea = request.POST['sarea']
        spin = request.POST['spin']


        if method == 'online':
            total_amount = 0
            for row in cart:
                total_amount = (int(row.food_item.price)* int(row.quantity)) + total_amount 
            order_info = Order.objects.create(amount=total_amount,date=date.today(),status='pending',customer_id=cus.id,seller_id=row.food_item.seller_id)

            for row in cart:
                tprice = row.food_item.price*row.quantity
                Order_details.objects.create(quantity=row.quantity,price=tprice,order_id=order_info.id,food_item_id=row.food_item.id,seller_id=row.food_item.seller_id)
            pd_info = Payment_Details.objects.create(payment_method='online',payment_id='p_id from razor pay',signature='sign_id from razor pay',order_id=order_info.id)
            Shipping.objects.create(name=sname,address=saddress,email=semail,phone=sphone,pin=spin,area_id=sarea,city_id=scity,order_id=order_info.id,payment_details_id=pd_info.id,customer_id=cus.id)
            Billing.objects.create(name=name,address=address,email=email,phone=phone,pin=pin,area_id=area,city_id=city,order_id=order_info.id,payment_details_id=pd_info.id,customer_id=cus.id)
            cart_clear = Cart.objects.filter(customer_id=cus.id)
            request.session['pd_id'] = pd_info.id 
            data = {'status':'success'}
            Order.objects.update_or_create(pk=order_info.id,defaults=data)

            
            return redirect('/customer/make_payment')

            cart_clear.delete()


        else:
            total_amount = 0
            for row in cart:
                total_amount = (int(row.food_item.price)* int(row.quantity)) + total_amount 
            order_info = Order.objects.create(amount=total_amount,date=date.today(),status='pending',customer_id=cus.id,seller_id=row.food_item.seller_id)

            for row in cart:
                tprice = row.food_item.price*row.quantity
                Order_details.objects.create(quantity=row.quantity,price=tprice,order_id=order_info.id,food_item_id=row.food_item.id,seller_id=row.food_item.seller_id)
            pd_info = Payment_Details.objects.create(payment_method='cod',payment_id='cod',signature='cod',order_id=order_info.id)
            Shipping.objects.create(name=sname,address=saddress,email=semail,phone=sphone,pin=spin,area_id=sarea,city_id=scity,order_id=order_info.id,payment_details_id=pd_info.id,customer_id=cus.id)
            Billing.objects.create(name=name,address=address,email=email,phone=phone,pin=pin,area_id=area,city_id=city,order_id=order_info.id,payment_details_id=pd_info.id,customer_id=cus.id)
            cart_clear = Cart.objects.filter(customer_id=cus.id)
            data = {'status':'success'}
            Order.objects.update_or_create(pk=order_info.id,defaults=data)

            id = request.user.id
            user = User.objects.get(pk=id)

            # pdf = gen_pdf(request)
            buffer = BytesIO()
            page_size = portrait(letter)
            p = canvas.Canvas(buffer, pagesize=page_size)
            # Add the table header


            # Add the invoice header
            p.setFillColorRGB(0, 0, 0.77)
            p.setFont('Helvetica-Bold', 20)
            p.drawCentredString(page_size[0] / 2, 750, 'Invoice')


            # Add the order details
            p.setFont('Helvetica', 12)
            p.drawString(450, 700, f'Order ID: {order_info.id}')
            now=datetime.now()
            p.drawString(450, 675, f'Date: {now.strftime("%Y-%m-%d %H:%M:%S")}')
            p.drawString(60, 700, f'Customer Name: {cus.user.first_name}')
            p.drawString(60, 675, f'Customer Email: {cus.user.email}')
            p.drawString(60, 650, f'Customer Phone: {cus.contact}')
    
            p.line(60, 625, 600, 625)


             # Add the table header
            p.setFillColorRGB(0.8, 0.8, 0.8)
            p.rect(50, 550, page_size[0] - 70, 25, fill=True)
            p.setFillColorRGB(0, 0, 0)
            p.setFont('Helvetica-Bold', 12)
            p.drawString(60, 557, 'Product')
            p.drawString(300, 557, 'Quantity')
            p.drawString(450, 557, 'Price')
            p.drawString(550, 557, 'Total')

            # Add the table rows
            y = 525
            for item in cart:
                p.setFont('Helvetica', 10)
                p.drawString(60, y, item.food_item.name)
                p.drawString(300, y, str(item.quantity))
                p.drawString(450, y, f'\u20B9{item.price}')
                p.drawString(550, y, f'\u20B9{item.quantity * item.price}')
                y -= 25


                # Add the table footer
            p.setFillColorRGB(0.8, 0.8, 0.8)
            p.rect(50, y-10, page_size[0] - 70, 25, fill=True)
            p.setFillColorRGB(0, 0, 0)
            p.setFont('Helvetica-Bold', 12)
            p.drawString(60, y + 2, 'Total')
            p.drawString(550, y + 2, f'\u20B9{order_info.amount}')
        
            p.showPage()
            p.save()

    # Create an email message
            pdf = buffer.getvalue()
            # buffer.close()

            email = EmailMessage(
            'Testing Mail',
            'Login Sucessfully',
            'thefoodiezone2550@gmail.com',
            [user.email]
            )
            email.attach('bill.pdf', pdf, 'application/pdf')

        # Send the email
            email.send()
            cart_clear.delete()


        return redirect('/customer/success_payment')

    else:
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        address = request.POST['address']
        city = request.POST['city']
        area = request.POST['area']
        pin = request.POST['pin']

        if method == 'online':
            total_amount = 0
            for row in cart:
                total_amount = (int(row.food_item.price)* int(row.quantity)) + total_amount 

            order_info = Order.objects.create(amount=total_amount,date=date.today(),status='pending',customer_id=cus.id,seller_id=row.food_item.seller_id)

            for row in cart:
                tprice = row.food_item.price*row.quantity
                Order_details.objects.create(quantity=row.quantity,price=tprice,order_id=order_info.id,food_item_id=row.food_item.id,seller_id=row.food_item.seller_id)
            pd_info = Payment_Details.objects.create(payment_method='online',payment_id='p_id from razor pay',signature='sign_id from razor pay',order_id=order_info.id)
            Shipping.objects.create(name=name,address=address,email=email,phone=phone,pin=pin,area_id=area,city_id=city,order_id=order_info.id,payment_details_id=pd_info.id,customer_id=cus.id)
            Billing.objects.create(name=name,address=address,email=email,phone=phone,pin=pin,area_id=area,city_id=city,order_id=order_info.id,payment_details_id=pd_info.id,customer_id=cus.id)
            cart_clear = Cart.objects.filter(customer_id=cus.id)
            request.session['pd_id'] = pd_info.id 
            data = {'status':'success'}
            Order.objects.update_or_create(pk=order_info.id,defaults=data)
            return redirect('/customer/make_payment')
        

        
            cart_clear.delete()

        else:
            total_amount = 0
            for row in cart:
                total_amount = (int(row.food_item.price)* int(row.quantity)) + total_amount 
            order_info = Order.objects.create(amount=total_amount,date=date.today(),status='pending',customer_id=cus.id,seller_id=row.food_item.seller_id)

            for row in cart:
                print(row.food_item.price)
                tprice = (row.food_item.price)*(row.quantity)
                print(row.food_item.price*row.quantity)
                Order_details.objects.create(quantity=row.quantity,price=tprice,order_id=order_info.id,food_item_id=row.food_item.id,seller_id=row.food_item.seller_id)
            pd_info = Payment_Details.objects.create(payment_method='cod',payment_id='cod',signature='cod',order_id=order_info.id)
            Shipping.objects.create(name=name,address=address,email=email,phone=phone,pin=pin,area_id=area,city_id=city,order_id=order_info.id,payment_details_id=pd_info.id,customer_id=cus.id)

            Billing.objects.create(name=name,address=address,email=email,phone=phone,pin=pin,area_id=area,city_id=city,order_id=order_info.id,payment_details_id=pd_info.id,customer_id=cus.id)
            cart_clear = Cart.objects.filter(customer_id=cus.id)
            data = {'status':'success'}
            Order.objects.update_or_create(pk=order_info.id,defaults=data)

            id = request.user.id
            user = User.objects.get(pk=id)

            # pdf = gen_pdf(request)
            buffer = BytesIO()
            page_size = portrait(letter)
            p = canvas.Canvas(buffer, pagesize=page_size)
            # Add the table header


            # Add the invoice header
            p.setFillColorRGB(0, 0, 0.77)
            p.setFont('Helvetica-Bold', 20)
            p.drawCentredString(page_size[0] / 2, 750, 'Invoice')


            # Add the order details
            p.setFont('Helvetica', 12)
            p.drawString(500, 700, f'Order ID: {order_info.id}')
            now=datetime.now()
            p.drawString(500, 675, f'Date: {now.strftime("%Y-%m-%d %H:%M:%S")}')
            # pdf_canvas.drawString(100, 675, f'Date: {order.created_at.strftime("%Y-%m-%d %H:%M:%S")}')
            p.drawString(100, 700, f'Customer Name: {cus.user.first_name}')
            p.drawString(100, 675, f'Customer Email: {cus.user.email}')
            p.drawString(100, 650, f'Customer Phone: {cus.contact}')

            p.drawLine(100, 625, 600, 625)


             # Add the table header
            p.setFillColorRGB(0.8, 0.8, 0.8)
            p.rect(50, 500, page_size[0] - 70, 25, fill=True)
            p.setFillColorRGB(0, 0, 0)
            p.setFont('Helvetica-Bold', 12)
            p.drawString(60, 507, 'Product')
            p.drawString(300, 507, 'Quantity')
            p.drawString(450, 507, 'Price')
            p.drawString(550, 507, 'Total')

            # Add the table rows
            y = 475
            for item in cart:
                p.setFont('Helvetica', 10)
                p.drawString(60, y, item.food_item.name)
                p.drawString(300, y, str(item.quantity))
                p.drawString(450, y, f'\u20B9{item.price}')
                p.drawString(550, y, f'\u20B9{item.quantity * item.price}')
                y -= 25


                # Add the table footer
            p.setFillColorRGB(0.8, 0.8, 0.8)
            p.rect(50, y-10, page_size[0] - 70, 25, fill=True)
            p.setFillColorRGB(0, 0, 0)
            p.setFont('Helvetica-Bold', 12)
            p.drawString(60, y + 2, 'Total')
            p.drawString(550, y + 2, f'\u20B9{order_info.amount}')
        
            p.showPage()
            p.save()

    # Create an email message
            pdf = buffer.getvalue()
            # buffer.close()

            email = EmailMessage(
            'Testing Mail',
            'Login Sucessfully',
            'thefoodiezone2550@gmail.com',
            [user.email]
            )
            email.attach('bill.pdf', pdf, 'application/pdf')

        # Send the email
            email.send()

            cart_clear.delete()
            return redirect('/customer/success_payment')



def make_payment(request):
    pd_id = request.session['pd_id']  
    key_id = 'rzp_test_z6P1wwC1BIUryt'
    key_secret = 'la8qYDjpaA8gGqbuhjmqubDu'

    cus = Customer.objects.get(user_id=request.user.id)
    cart = Cart.objects.filter(customer_id=cus.id)
    total_amount = 0
    for row in cart:
        total_amount = (int(row.food_item.price)* int(row.quantity)) + total_amount 

    amount_total = total_amount
    print(amount_total)
    print(type(amount_total))
    client = razorpay.Client(auth=(key_id, key_secret))

    data = {
        'amount': int(amount_total)*100,
        'currency': 'INR',
        "receipt":"The Foozdie Zone",
        "notes":{
            'name' : 'request.user.first_name',
            'payment_for':'Payment Test'
        }
    }

    data_pd = {'payment_id':'razorpay','signature':'razorpay'}
    phone = Customer.objects.get(user_id=request.user.id).contact
    payment = client.order.create(data=data)
    Payment_Details.objects.update_or_create(pk=pd_id,defaults=data_pd)
    context = {'payment' : payment,'total_amount':total_amount,'phone':phone,}
    return render(request, 'customer/process_payment.html',context)



@csrf_exempt
def r_details(request):
    pd_id = request.session['pd_id']
    user = request.user.id
    cus = Customer.objects.get(user_id=request.user.id)
    order_id = request.POST.get('razorpay_order_id')
    payment_id = request.POST.get('razorpay_payment_id')
    signature = request.POST.get('razorpay_signature')
    client = razorpay.Client(auth=("rzp_test_z6P1wwC1BIUryt", "la8qYDjpaA8gGqbuhjmqubDu"))
    # print(client.utility.verify_payment_signature)


    
    pdf = gen_pdf(request)
    email = EmailMessage(
            'Testing Mail',
            'Login Sucessfully',
            'thefoodiezone2550@gmail.com',
            [cus.user.email]
            )
    email.attach('bill.pdf', pdf, 'application/pdf')

        # Send the email
    email.send()
    
    try:
        client.utility.verify_payment_signature({
            'razorpay_order_id': order_id,
            'razorpay_payment_id': payment_id,
            'razorpay_signature': signature
        })
        print("Success")
        data_pd = {'payment_id':payment_id,'signature':signature}
        Payment_Details.objects.update_or_create(pk=pd_id,defaults=data_pd)
        # Maintenance_Payment.objects.create(order_id=order_id,payment_id=payment_id,signature=signature,date_time=datetime.today(),member_id=result,maintenance_id=id)
        # Payment is successful, do something here


        return redirect('/customer/success_payment')

    except:
        print("Failure") 
        # Payment failed, do something here

@csrf_exempt
def success_payment(request):
    context = {}
    return render(request, 'customer/success_payment.html',context)


def gen_pdf(request):
    id = request.user.id

    user = User.objects.get(pk=id)
    cus = Customer.objects.get(user_id=id)
    cart = Cart.objects.filter(customer_id=cus.id)

    buffer = BytesIO()
    page_size = portrait(letter)
    p = canvas.Canvas(buffer, pagesize=page_size)
    # Add the table header


    # Add the invoice header
    p.setFillColorRGB(0, 0, 0.77)
    p.setFont('Helvetica-Bold', 20)
    p.drawCentredString(page_size[0] / 2, 750, 'Invoice')

    # Add the order details
    p.setFont('Helvetica', 12)
    # p.drawString(500, 700, f'Order ID: {order_info.id}')
    now=datetime.now()
    p.drawString(500, 675, f'Date: {now.strftime("%Y-%m-%d %H:%M:%S")}')
    # pdf_canvas.drawString(100, 675, f'Date: {order.created_at.strftime("%Y-%m-%d %H:%M:%S")}')
    p.drawString(100, 700, f'Customer Name: {cus.user.first_name}')
    p.drawString(100, 675, f'Customer Email: {cus.user.email}')
    p.drawString(100, 650, f'Customer Phone: {cus.contact}')

    p.line(100, 625, 600, 625)


        # Add the table header
    p.setFillColorRGB(0.8, 0.8, 0.8)
    p.rect(50, 500, page_size[0] - 70, 25, fill=True)
    p.setFillColorRGB(0, 0, 0)
    p.setFont('Helvetica-Bold', 12)
    p.drawString(60, 507, 'Product')
    p.drawString(300, 507, 'Quantity')
    p.drawString(450, 507, 'Price')
    p.drawString(550, 507, 'Total')

    # Add the table rows
    total = 0
    y = 475
    for item in cart:
        p.setFont('Helvetica', 10)
        p.drawString(60, y, item.food_item.name)
        p.drawString(300, y, str(item.quantity))
        p.drawString(450, y, f'\u20B9{item.price}')
        p.drawString(550, y, f'\u20B9{item.quantity * item.price}')
        total = total + (item.quantity * item.price)
        y -= 25


        # Add the table footer
    p.setFillColorRGB(0.8, 0.8, 0.8)
    p.rect(50, y-10, page_size[0] - 70, 25, fill=True)
    p.setFillColorRGB(0, 0, 0)
    p.setFont('Helvetica-Bold', 12)
    p.drawString(60, y + 2, 'Total')
    p.drawString(550, y + 2, f'\u20B9{total}')

    p.showPage()
    p.save()

# Create an email message
    pdf = buffer.getvalue()
    buffer.close()
    return pdf
