"""TheFoodieZone URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from customer import views

urlpatterns = [
    path('home', views.home, name='home'),
    path('layout', views.layout, name='layout'),
    path('registration', views.registration, name='registration'),
    path('login', views.login, name='login'),
    path('login_check', views.login_check, name='login_check'),
    path('logout', views.logout, name='logout'),

    path('sidebar', views.sidebar, name='sidebar'),
    path('header', views.header, name='header'),
    path('footer', views.footer, name='footer'),
    path('inquiry',views.inquiry,name='inquiry'),
    path('store_inquiry/<int:id>',views.store_inquiry,name='store_inquiry'),
    path('feedback',views.feedback,name='inquiry'),
    path('store_feedback/<int:id>',views.store_feedback,name='store_feedback'),
    # path('store_inquiry/<int:id>',views.store_inquiry,name='store_inquiry'),
    # path('cust_reg', views.cust_reg, name='cust_reg'),
    path('store_customer', views.store_customer, name='store_customer'),
    path('fooditems/<int:id>/<int:res_id>', views.fooditems, name='fooditems'),
    path('resturant_category/<int:id>', views.resturant_category, name='resturant_category'),
    path('res_load', views.res_load, name='res_load'),

    # path('cart/<int:id>/<int:cat_id>/<int:res_id>', views.cart, name='cart'),
    path('view_cart', views.view_cart, name='view_cart'),
    path('add_cart/<int:id>', views.add_cart, name='add_cart'),
    path('remove_item/<int:id>', views.remove_item, name='remove_item'),
    path('update_cart', views.update_cart, name='update_cart'),

    path('checkout', views.checkout, name='checkout'),

    # path('order', views.order, name='oerder'),
   
    path('success_payment', views.success_payment, name='success_payment'),
    path('r_details', views.r_details, name='r_details'),
    path('place_order', views.place_order, name='place_order'),
    path('make_payment', views.make_payment, name='make_payment'),

]
